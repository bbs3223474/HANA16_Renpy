﻿unarc is a tool used to unpack the special .arc format. Essentially this kind of .arc is a duplication to .zip except for the signature. .arc with the signature "AR" against .zip with the signature "PK". You could use unarc as if playing unzip :)
unarc was compiled from unzip-5.20 source.
The games support list for unarc can be found at the top directory of crass.
Please run unarc under the console.

unarc是一个提取具有特殊格式的.arc的工具。实际上这种.arc和.zip的差别就在于.arc的标识是"AR"而.zip的标识是"PK"，所以你可以把unarc当作unzip来使用 :)
unarc是由unzip-5.20源码编译的。
unarc的游戏支持列表放在了crass的根目录下。
unarc必须在控制台下才能运行。
