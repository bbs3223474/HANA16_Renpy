﻿    Crass意指Crage和Assage两个工具的集合。Crage是使用cui插件扩展的游戏资源提取器；而Assage是使用aui插件扩展的游戏资源封装程序。
    
    只要正确使用cui或aui插件，就可以提取或封装各自对应的封包文件。

    提取时使用的程序是crage.exe，它是一个控制台程序；如果你更习惯使用图形界面，可以使用CrageGUI，它是crage.exe的一个GUI包装程序。有关crage的更多使用说明参见FAQ.txt和INSTALL.txt；另外document中是每个cui插件的详细信息，解包前应当阅读。

    注：因为时间和难度因素，暂时不考虑开发Assage和aui。

	crass最新版本：（只有在blog无法使用时才会临时转到飞雪之城：https://www.yukict.com/bbs/forumdisplay.php?fid=69）
		http://galcrass.blog124.fc2.com/

	cui更新版本：
		http://galcrass.blog124.fc2.com/blog-entry-1.html

	部分cui源码（ver 1.0.4）：
		http://www.aishare.net/link.php?ref=tYsE9l9Nyu

	提问和问题报告：（请报告完整的提取错误信息）
		https://www.yukict.com/bbs/thread-13010-1-1.html(可匿名)

	pcicp的游戏支持列表：
		http://haibarascgrip.baywords.com/

	Crass在使用插件系统之前的程序（已经停止维护）：
		http://bbs.jgames.net/ForumDisplay.asp?RootID=195845&forumid=1
